// 이 파일은 백엔드 연결 전 테스트용으로 사용할 수 있습니다
export const mockPosts = [
  {
    id: 1,
    title: "강아지랑 부산여행",
    author: "멍멍맘",
    createdAt: "2023-05-15",
    commentCount: 3,
    viewCount: 142,
  },
  {
    id: 2,
    title: "고양이와 함께하는 캠핑",
    author: "냥이집사",
    createdAt: "2023-05-14",
    commentCount: 7,
    viewCount: 218,
  },
  {
    id: 3,
    title: "반려견 동반 카페 추천",
    author: "멍멍파파",
    createdAt: "2023-05-12",
    commentCount: 5,
    viewCount: 95,
  },
  {
    id: 4,
    title: "우리 토끼 첫 산책",
    author: "토끼맘",
    createdAt: "2023-05-10",
    commentCount: 4,
    viewCount: 156,
  },
]

